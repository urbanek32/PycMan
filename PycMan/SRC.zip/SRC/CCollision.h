#include "headers.h"

#ifndef CCOLL_H
#define CCOLL_H
class CCollision
{
public:
	CCollision();

	static bool Collision(sf::Vector2f & ObjectPosition, const sf::Image& screenCapture, const sf::Color & CollisionColor);

private:
	
};
#endif