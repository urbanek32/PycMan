#include "headers.h"

CCollision::CCollision()
{
	
}

bool CCollision::Collision(sf::Vector2f & ObjectPosition, const sf::Image& screenCapture, const sf::Color & CollisionColor)
{
	//sf::Image screenCapture = App.Capture();
	for(unsigned int i=0; i< PlayerSize.x; i++)
	{
		for(unsigned int j=0; j< PlayerSize.y; j++)
		{
			if(screenCapture.getPixel( (unsigned int)(ObjectPosition.x +i -(PlayerSize.x/2)+2.5) , (unsigned int)(ObjectPosition.y + j -(PlayerSize.y/2)+2.5) ) == CollisionColor)
			{
				return true;
			}
		}
	}
	return false;
}